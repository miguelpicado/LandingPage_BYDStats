import{d as r}from"./chunk-BnC0VW1S.js";const e=({children:o})=>r.createPortal(o,document.body);export{e as M};
