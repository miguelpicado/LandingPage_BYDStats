import{c as t}from"./assets/index-6vnggLOi.js";const o=t("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{o as C};
