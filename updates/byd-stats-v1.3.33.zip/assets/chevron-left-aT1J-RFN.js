import{c as o}from"./index-ONqkeBYC.js";const t=o("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);export{t as C};
