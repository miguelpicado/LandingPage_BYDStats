import{c as t}from"./index-ONqkeBYC.js";const o=t("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{o as C};
