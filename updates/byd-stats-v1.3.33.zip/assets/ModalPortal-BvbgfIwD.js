import{d as r}from"./vendor-react-Drs83nZr.js";const e=({children:o})=>r.createPortal(o,document.body);export{e as M};
