import{a as r}from"./vendor-react-B2ijlRyv.js";const a=({children:o})=>r.createPortal(o,document.body);export{a as M};
