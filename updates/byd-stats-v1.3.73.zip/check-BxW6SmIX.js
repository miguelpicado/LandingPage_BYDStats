import{c}from"./bootstrap-Bc__42tU.js";const t=c("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{t as C};
