import{c as o}from"./bootstrap-Bc__42tU.js";const e=o("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);export{e as C};
