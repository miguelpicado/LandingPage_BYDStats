// Cargado por el service worker (workbox.importScripts en vite.config.ts).
// PWA-002: al activar un SW nuevo, borra del Cache Storage lo que ninguna version actual usa
// (p.ej. 'google-drive-api' y 'firestore-api' de versiones antiguas, con respuestas autenticadas).
// El precache de workbox lo limpia cleanupOutdatedCaches; aqui se conservan sus cachés (prefijo
// 'workbox-') y los runtimeCaching de vite.config.ts. Si se anade un cacheName nuevo, ponerlo aqui.
// carImageCache vive en IndexedDB ('byd-car-images'), no en Cache Storage: esto no lo toca.
// ponytail: lista fija de nombres; si crecen, derivarla de un unico sitio compartido con vite.config.ts.
(function () {
    var KEEP = ['i18n-locales', 'app-chunks', 'sqljs'];

    function isCurrent(name) {
        return name.indexOf('workbox-') === 0 || KEEP.indexOf(name) !== -1;
    }

    self.addEventListener('activate', function (event) {
        event.waitUntil(
            caches.keys().then(function (names) {
                return Promise.all(
                    names.filter(function (n) { return !isCurrent(n); })
                        .map(function (n) { return caches.delete(n); })
                );
            }).catch(function () { /* purga best-effort: nunca debe romper la activacion del SW */ })
        );
    });
})();
