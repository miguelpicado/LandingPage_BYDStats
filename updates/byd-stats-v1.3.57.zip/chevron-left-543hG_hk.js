import{c as e}from"./assets/index-Dzq1WU7T.js";const t=e("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);export{t as C};
