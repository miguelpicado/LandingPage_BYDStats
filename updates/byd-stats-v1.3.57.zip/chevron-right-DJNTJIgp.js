import{c as t}from"./assets/index-Dzq1WU7T.js";const o=t("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{o as C};
