import{c as o}from"./assets/index-wnXJyAfY.js";const n=o("navigation",[["polygon",{points:"3 11 22 2 13 21 11 13 3 11",key:"1ltx0t"}]]);export{n as N};
