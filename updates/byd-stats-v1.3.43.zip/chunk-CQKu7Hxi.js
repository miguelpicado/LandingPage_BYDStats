import{c as s}from"./assets/index-wnXJyAfY.js";const p=s("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);export{p as P};
