import{c as o}from"./bootstrap-kP3i_GQe.js";const e=o("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);export{e as C};
