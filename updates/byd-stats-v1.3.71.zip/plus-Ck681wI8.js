import{c as s}from"./bootstrap-kP3i_GQe.js";const a=s("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);export{a as P};
