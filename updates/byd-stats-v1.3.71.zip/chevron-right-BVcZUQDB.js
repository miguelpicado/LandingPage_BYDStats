import{c as t}from"./bootstrap-kP3i_GQe.js";const h=t("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
