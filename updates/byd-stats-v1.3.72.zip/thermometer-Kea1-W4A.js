import{c as t}from"./bootstrap-CxqSxKtw.js";const o=t("thermometer",[["path",{d:"M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z",key:"17jzev"}]]);export{o as T};
