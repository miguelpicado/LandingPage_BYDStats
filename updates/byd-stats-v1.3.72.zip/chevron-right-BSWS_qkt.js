import{c as t}from"./bootstrap-CxqSxKtw.js";const h=t("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
