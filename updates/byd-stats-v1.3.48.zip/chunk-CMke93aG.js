import{d as r}from"./chunk-K4cmqOvl.js";const e=({children:o})=>r.createPortal(o,document.body);export{e as M};
