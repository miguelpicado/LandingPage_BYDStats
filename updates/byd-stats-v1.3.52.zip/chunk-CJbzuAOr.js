import{c as e}from"./assets/index-CH8N6Oqi.js";const a=e("thermometer",[["path",{d:"M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z",key:"17jzev"}]]);export{a as T};
