import{d as r}from"./chunk-BD393xee.js";const e=({children:o})=>r.createPortal(o,document.body);export{e as M};
