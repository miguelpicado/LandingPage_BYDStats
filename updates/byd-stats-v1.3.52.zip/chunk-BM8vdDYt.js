import{c}from"./assets/index-CH8N6Oqi.js";const s=c("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{s as C};
