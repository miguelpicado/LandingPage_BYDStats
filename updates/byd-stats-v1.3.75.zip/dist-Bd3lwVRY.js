import{n as e,r as t}from"./rolldown-runtime-CwZLBQsm.js";import{u as n}from"./vendor-react-C_x5Or5A.js";var r,i,a,o=t(n(),1),s={data:``},c=e=>{if(typeof window==`object`){let t=(e?e.querySelector(`#_goober`):window._goober)||Object.assign(document.createElement(`style`),{innerHTML:` `,id:`_goober`});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||s},l=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,u=/\/\*[^]*?\*\/|  +/g,d=/\n+/g,f=(e,t)=>{let n=``,r=``,i=``;for(let a in e){let o=e[a];a[0]==`@`?a[1]==`i`?n=a+` `+o+`;`:r+=a[1]==`f`?f(o,a):a+`{`+f(o,a[1]==`k`?``:t)+`}`:typeof o==`object`?r+=f(o,t?t.replace(/([^,])+/g,e=>a.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+` `+t:t)):a):o!=null&&(a=/^--/.test(a)?a:a.replace(/[A-Z]/g,`-$&`).toLowerCase(),i+=f.p?f.p(a,o):a+`:`+o+`;`)}return n+(t&&i?t+`{`+i+`}`:i)+r},p={},m=e=>{if(typeof e==`object`){let t=``;for(let n in e)t+=n+m(e[n]);return t}return e},h=(e,t,n,r,i)=>{let a=m(e),o=p[a]||(p[a]=(e=>{let t=0,n=11;for(;t<e.length;)n=101*n+e.charCodeAt(t++)>>>0;return`go`+n})(a));if(!p[o]){let t=a===e?(e=>{let t,n,r=[{}];for(;t=l.exec(e.replace(u,``));)t[4]?r.shift():t[3]?(n=t[3].replace(d,` `).trim(),r.unshift(r[0][n]=r[0][n]||{})):r[0][t[1]]=t[2].replace(d,` `).trim();return r[0]})(e):e;p[o]=f(i?{[`@keyframes `+o]:t}:t,n?``:`.`+o)}let s=n&&p.g?p.g:null;return n&&(p.g=p[o]),((e,t,n,r)=>{r?t.data=t.data.replace(r,e):t.data.indexOf(e)===-1&&(t.data=n?e+t.data:t.data+e)})(p[o],t,r,s),o};function g(e){let t=this||{},n=e.call?e(t.p):e;return h(n.unshift?n.raw?((e,t,n)=>e.reduce((e,r,i)=>{let a=t[i];if(a&&a.call){let e=a(n),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;a=t?`.`+t:e&&typeof e==`object`?e.props?``:f(e,``):!1===e?``:e}return e+r+(a??``)},``))(n,[].slice.call(arguments,1),t.p):n.reduce((e,n)=>Object.assign(e,n&&n.call?n(t.p):n),{}):n,c(t.target),t.g,t.o,t.k)}g.bind({g:1});var _=g.bind({k:1});function v(e,t){let n=this||{};return function(){let o=arguments;function s(c,l){let u=Object.assign({},c),d=u.className||s.className;n.p=Object.assign({theme:i&&i()},u),n.o=/ *go\d+/.test(d),u.className=g.apply(n,o)+(d?` `+d:``),t&&(u.ref=l);let f=e;return e[0]&&(f=u.as||e,delete u.as),a&&f[0]&&a(u),r(f,u)}return t?t(s):s}}var y=e({default:()=>$}),b=(e,t)=>(e=>typeof e==`function`)(e)?e(t):e,x=(()=>{let e=0;return()=>(++e).toString()})(),S=(()=>{let e;return()=>{if(e===void 0&&typeof window<`u`){let t=matchMedia(`(prefers-reduced-motion: reduce)`);e=!t||t.matches}return e}})(),C=`default`,w=(e,t)=>{let{toastLimit:n}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,n)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return w(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:i}=t;return{...e,toasts:e.toasts.map(e=>e.id===i||i===void 0?{...e,dismissed:!0,visible:!1}:e)};case 4:return t.toastId===void 0?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let a=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+a}))}}},T=[],E={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},D={},O=(e,t=C)=>{D[t]=w(D[t]||E,e),T.forEach(([e,n])=>{e===t&&n(D[t])})},k=e=>Object.keys(D).forEach(t=>O(e,t)),A=(e=C)=>t=>{O(t,e)},j={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},M=e=>(t,n)=>{let r=((e,t=`blank`,n)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:`status`,"aria-live":`polite`},message:e,pauseDuration:0,...n,id:n?.id||x()}))(t,e,n);return A(r.toasterId||(e=>Object.keys(D).find(t=>D[t].toasts.some(t=>t.id===e)))(r.id))({type:2,toast:r}),r.id},N=(e,t)=>M(`blank`)(e,t);N.error=M(`error`),N.success=M(`success`),N.loading=M(`loading`),N.custom=M(`custom`),N.dismiss=(e,t)=>{let n={type:3,toastId:e};t?A(t)(n):k(n)},N.dismissAll=e=>N.dismiss(void 0,e),N.remove=(e,t)=>{let n={type:4,toastId:e};t?A(t)(n):k(n)},N.removeAll=e=>N.remove(void 0,e),N.promise=(e,t,n)=>{let r=N.loading(t.loading,{...n,...n?.loading});return typeof e==`function`&&(e=e()),e.then(e=>{let i=t.success?b(t.success,e):void 0;return i?N.success(i,{id:r,...n,...n?.success}):N.dismiss(r),e}).catch(e=>{let i=t.error?b(t.error,e):void 0;i?N.error(i,{id:r,...n,...n?.error}):N.dismiss(r)}),e};var P=_`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,F=_`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,I=_`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,L=v(`div`)`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||`#ff4b4b`};
  position: relative;
  transform: rotate(45deg);

  animation: ${P} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||`#fff`};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${I} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,R=_`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,z=v(`div`)`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||`#e0e0e0`};
  border-right-color: ${e=>e.primary||`#616161`};
  animation: ${R} 1s linear infinite;
`,B=_`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,V=_`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,H=v(`div`)`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||`#61d345`};
  position: relative;
  transform: rotate(45deg);

  animation: ${B} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${V} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||`#fff`};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,U=v(`div`)`
  position: absolute;
`,W=v(`div`)`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,G=_`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,K=v(`div`)`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${G} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,q=({toast:e})=>{let{icon:t,type:n,iconTheme:r}=e;return t===void 0?n===`blank`?null:o.createElement(W,null,o.createElement(z,{...r}),n!==`loading`&&o.createElement(U,null,n===`error`?o.createElement(L,{...r}):o.createElement(H,{...r}))):typeof t==`string`?o.createElement(K,null,t):t},J=e=>`\n0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}\n100% {transform: translate3d(0,0,0) scale(1); opacity:1;}\n`,Y=e=>`\n0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}\n100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}\n`,X=v(`div`)`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Z=v(`div`)`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Q=o.memo(({toast:e,position:t,style:n,children:r})=>{let i=e.height?((e,t)=>{let n=e.includes(`top`)?1:-1,[r,i]=S()?[`0%{opacity:0;} 100%{opacity:1;}`,`0%{opacity:1;} 100%{opacity:0;}`]:[J(n),Y(n)];return{animation:t?`${_(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${_(i)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||`top-center`,e.visible):{opacity:0},a=o.createElement(q,{toast:e}),s=o.createElement(Z,{...e.ariaProps},b(e.message,e));return o.createElement(X,{className:e.className,style:{...i,...n,...e.style}},typeof r==`function`?r({icon:a,message:s}):o.createElement(o.Fragment,null,a,s))});(function(e){f.p=void 0,r=e,i=void 0,a=void 0})(o.createElement);var ee=({id:e,className:t,style:n,onHeightUpdate:r,children:i})=>{let a=o.useCallback(t=>{if(t){let n=()=>{let n=t.getBoundingClientRect().height;r(e,n)};n(),new MutationObserver(n).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return o.createElement(`div`,{ref:a,className:t,style:n},i)},te=g`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ne=({reverseOrder:e,position:t=`top-center`,toastOptions:n,gutter:r,children:i,toasterId:a,containerStyle:s,containerClassName:c})=>{let{toasts:l,handlers:u}=((e,t=`default`)=>{let{toasts:n,pausedAt:r}=((e={},t=C)=>{let[n,r]=(0,o.useState)(D[t]||E),i=(0,o.useRef)(D[t]);(0,o.useEffect)(()=>(i.current!==D[t]&&r(D[t]),T.push([t,r]),()=>{let e=T.findIndex(([e])=>e===t);e>-1&&T.splice(e,1)}),[t]);let a=n.toasts.map(t=>({...e,...e[t.type],...t,removeDelay:t.removeDelay||e[t.type]?.removeDelay||e?.removeDelay,duration:t.duration||e[t.type]?.duration||e?.duration||j[t.type],style:{...e.style,...e[t.type]?.style,...t.style}}));return{...n,toasts:a}})(e,t),i=(0,o.useRef)(new Map).current,a=(0,o.useCallback)((e,t=1e3)=>{if(i.has(e))return;let n=setTimeout(()=>{i.delete(e),s({type:4,toastId:e})},t);i.set(e,n)},[]);(0,o.useEffect)(()=>{if(r)return;let e=Date.now(),i=n.map(n=>{if(n.duration===1/0)return;let r=(n.duration||0)+n.pauseDuration-(e-n.createdAt);if(!(r<0))return setTimeout(()=>N.dismiss(n.id,t),r);n.visible&&N.dismiss(n.id)});return()=>{i.forEach(e=>e&&clearTimeout(e))}},[n,r,t]);let s=(0,o.useCallback)(A(t),[t]),c=(0,o.useCallback)(()=>{s({type:5,time:Date.now()})},[s]),l=(0,o.useCallback)((e,t)=>{s({type:1,toast:{id:e,height:t}})},[s]),u=(0,o.useCallback)(()=>{r&&s({type:6,time:Date.now()})},[r,s]),d=(0,o.useCallback)((e,t)=>{let{reverseOrder:r=!1,gutter:i=8,defaultPosition:a}=t||{},o=n.filter(t=>(t.position||a)===(e.position||a)&&t.height),s=o.findIndex(t=>t.id===e.id),c=o.filter((e,t)=>t<s&&e.visible).length;return o.filter(e=>e.visible).slice(...r?[c+1]:[0,c]).reduce((e,t)=>e+(t.height||0)+i,0)},[n]);return(0,o.useEffect)(()=>{n.forEach(e=>{if(e.dismissed)a(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[n,a]),{toasts:n,handlers:{updateHeight:l,startPause:c,endPause:u,calculateOffset:d}}})(n,a);return o.createElement(`div`,{"data-rht-toaster":a||``,style:{position:`fixed`,zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:`none`,...s},className:c,onMouseEnter:u.startPause,onMouseLeave:u.endPause},l.map(n=>{let a=n.position||t,s=((e,t)=>{let n=e.includes(`top`),r=n?{top:0}:{bottom:0},i=e.includes(`center`)?{justifyContent:`center`}:e.includes(`right`)?{justifyContent:`flex-end`}:{};return{left:0,right:0,display:`flex`,position:`absolute`,transition:S()?void 0:`all 230ms cubic-bezier(.21,1.02,.73,1)`,transform:`translateY(${t*(n?1:-1)}px)`,...r,...i}})(a,u.calculateOffset(n,{reverseOrder:e,gutter:r,defaultPosition:t}));return o.createElement(ee,{id:n.id,key:n.id,onHeightUpdate:u.updateHeight,className:n.visible?te:``,style:s},n.type===`custom`?b(n.message,n):i?i(n):o.createElement(Q,{toast:n,position:a}))}))},$=N;export{$ as i,y as n,N as r,ne as t};