import{c as o}from"./index-Dkoq1C69.js";const r=o("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{r as C};
