import{c}from"./index-Dkoq1C69.js";const o=c("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{o as C};
