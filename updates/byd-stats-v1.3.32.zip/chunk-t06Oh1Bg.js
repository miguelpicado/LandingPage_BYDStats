import{c as a}from"./assets/index-kKh4JrPF.js";const p=a("cloud",[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",key:"p7xjir"}]]);export{p as C};
