import{d as r}from"./chunk-BQPg0NGK.js";const e=({children:o})=>r.createPortal(o,document.body);export{e as M};
