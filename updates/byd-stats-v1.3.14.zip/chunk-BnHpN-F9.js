import{d as r}from"./chunk-DvmHlySd.js";const e=({children:o})=>r.createPortal(o,document.body);export{e as M};
