const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./chunk-reTYsubj.js","./chunk-CxjUwVX2.js","./chunk-CMGwAXRa.js","./chunk-ySrSLNgw.js","./chunk-CdMAbeiE.js","./chunk-Daer3YHK.js","./chunk-BPMFrEHg.js","./assets/vendor-leaflet-Dgihpmma.css","./chunk-BlXw2e6d.js","./chunk-BzE0_AIa.js","./assets/index-7SVko7PK.js","./assets/index-BuInIEs_.css","./chunk-baQ4-RG0.js","./chunk-Bsl_VCSb.js","./chunk-CbI2QISs.js","./chunk-ukwWyqsk.js","./chunk-DlRd8Lq5.js"])))=>i.map(i=>d[i]);
import{u as w,R as D,j as e,r as f,n as R,z as A}from"./chunk-CxjUwVX2.js";import{c as U,o as G,n as O,l as F,p as z,e as I,q as te,g as ae,r as se,s as _,t as $,k as L,Z as re,D as le,v as ne,w as ie,x as oe,y as ce,z as de,G as xe,H as me,I as he,T as ge,u as be}from"./assets/index-7SVko7PK.js";import{M as q}from"./chunk-9Lgpy07t.js";import{C as ue}from"./chunk-Ldtkm5nY.js";import{L as pe}from"./chunk-C_vpciB6.js";import{R as fe}from"./chunk-6E_SsRIh.js";import{D as ve}from"./chunk-Dsr1faXY.js";import{D as ke}from"./chunk-BKKXwZAB.js";import{_ as H,C as K,r as je}from"./chunk-ySrSLNgw.js";import{S as ye,Q as Ne,a9 as V,ac as Z,ag as J,ah as Q,a8 as Y,ab as X}from"./chunk-CdMAbeiE.js";import{C as we,g as Ce}from"./chunk-DkypVcIh.js";import{i as Se}from"./chunk-BaqeSYWG.js";import{T as Pe}from"./chunk-BuqZ1BZ7.js";import{u as De}from"./chunk-DMCcgJu5.js";import{B as Ae}from"./chunk-D8A5QoKC.js";import{E as Te}from"./chunk-CcLKjHdK.js";import"./chunk-CMGwAXRa.js";import"./chunk-Daer3YHK.js";import"./chunk-BPMFrEHg.js";import"./chunk-CgQWP2BK.js";import"./chunk-BzE0_AIa.js";const Fe=U("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]),ze=U("shield-alert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]),Ee=({googleSync:a})=>{const{t}=w(),{openModal:c}=G(),{exportSyncData:x}=O(),[d,u]=D.useState(!1),[g,i]=D.useState(!1);D.useEffect(()=>{u(!1)},[a.userProfile?.imageUrl]);const l=a.userProfile?.imageUrl,r=l&&!d;return e.jsxs("div",{className:"pt-4 border-t border-slate-200 dark:border-slate-700 mt-4",children:[e.jsxs("h4",{className:"text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2",children:[e.jsx(ue,{className:"w-4 h-4 text-blue-500"}),t("settings.googleDrive")]}),a.error&&!a.isAuthenticated&&e.jsx("div",{className:"mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-600 dark:text-red-400 break-all",children:a.error}),a.isAuthenticated?e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3 overflow-hidden",children:[r?e.jsx("img",{src:l,alt:"User",className:"w-10 h-10 rounded-full border border-slate-200 dark:border-slate-600",referrerPolicy:"no-referrer",onError:()=>u(!0)}):e.jsx("div",{className:"w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-800",children:a.userProfile?.name?.charAt(0)||"U"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2",children:a.userProfile?.name}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 truncate",children:a.userProfile?.email}),e.jsxs("div",{className:"flex items-center gap-1.5 mt-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full "+(a.isDriveReady?"bg-green-500 animate-pulse":"bg-amber-400")}),e.jsx("span",{className:"text-[10px] font-medium "+(a.isDriveReady?"text-green-600 dark:text-green-400":"text-amber-600 dark:text-amber-400"),children:a.isDriveReady?t("settings.connected"):t("settings.driveDisconnected","Drive desconectado")})]})]})]}),e.jsx("button",{onClick:a.logout,className:"p-2 -mr-2 rounded-xl text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors",title:t("settings.logout"),children:e.jsx(pe,{className:"w-5 h-5"})})]}),!a.isDriveReady&&e.jsxs("div",{className:"mb-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl",children:[e.jsx("p",{className:"text-xs text-amber-700 dark:text-amber-400 font-medium mb-2",children:t("settings.driveSessionExpired","La sesión de Drive ha expirado")}),e.jsx("button",{onClick:a.login,className:"w-full py-2 px-3 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white transition-all active:scale-[0.98]",children:t("settings.reconnectDrive","Reconectar Google Drive")})]}),e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("button",{onClick:a.syncNow,disabled:a.isSyncing,className:"w-full py-3 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2 "+(a.isSyncing?"bg-blue-400 cursor-not-allowed":"bg-blue-600 hover:bg-blue-700 shadow-blue-500/20"),children:[e.jsx(fe,{className:"w-4 h-4 "+(a.isSyncing?"animate-spin":"")}),a.isSyncing?t("settings.syncing"):t("settings.syncNow")]}),e.jsxs("button",{onClick:()=>c("backups"),className:"w-full py-3 px-4 rounded-xl text-sm font-medium bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]",children:[e.jsx(ve,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),t("settings.cloudBackups","Gestionar Copias en la Nube")]}),e.jsxs("button",{onClick:async()=>{i(!0);try{await x()}catch(o){F.error("Export failed:",o)}finally{i(!1)}},disabled:g,className:"w-full py-3 px-4 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] "+(g?"bg-slate-100 dark:bg-slate-700 text-slate-400 cursor-not-allowed":"bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600"),children:[g?e.jsx("div",{className:"w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"}):e.jsx(ke,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),g?t("sync.exporting","Exportando..."):t("settings.exportData","Exportar Todos los Datos")]})]}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-[10px] text-slate-400 px-1",children:[e.jsx("span",{children:a.lastSyncTime?`${t("settings.lastSync")}: ${a.lastSyncTime.toLocaleTimeString()}`:t("sync.neverSynced","Nunca sincronizado")}),a.error&&e.jsx("span",{className:"text-red-500 truncate max-w-[150px]",title:a.error,children:a.error})]})]}):e.jsxs("button",{onClick:a.login,className:"w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 font-medium rounded-xl px-4 py-3 transition-all shadow-sm active:scale-[0.98]",children:[e.jsxs("svg",{className:"w-5 h-5",viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",fill:"#4285F4"}),e.jsx("path",{d:"M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",fill:"#34A853"}),e.jsx("path",{d:"M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z",fill:"#FBBC05"}),e.jsx("path",{d:"M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",fill:"#EA4335"})]}),t("settings.signInWithGoogle")]})]})},Me=D.lazy(()=>H(()=>import("./chunk-reTYsubj.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13]),import.meta.url)),Be=()=>{const{t:a}=w(),{settings:t,updateSettings:c}=z(),{activeCar:x,updateCar:d,activeCarId:u,cars:g}=I(),{vehicles:i,loading:l}=te(),[r,o]=f.useState(null),b=f.useMemo(()=>{const s=new Map;return i.forEach(n=>{s.set(n.vin,{vin:n.vin,label:n.modelName?`${n.modelName} · ${n.vin}`:n.vin})}),x?.vin&&!s.has(x.vin)&&s.set(x.vin,{vin:x.vin,label:x.vin}),Array.from(s.values())},[i,x?.vin]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carModel",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carModel")}),e.jsxs("select",{id:"carModel",name:"carModel",value:t?.carModel||"",onChange:s=>c({...t,carModel:s.target.value,carColor:void 0}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600",children:[e.jsx("option",{value:"",children:a("settings.selectModel","Selecciona un modelo")}),we.map(({model:s})=>e.jsx("option",{value:s,children:s},s))]}),(()=>{const s=Ce(t?.carModel);return s?e.jsxs("div",{className:"mt-3",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carColor","Color del coche")}),e.jsx("div",{className:"flex flex-wrap gap-3",children:s.colors.map(n=>e.jsx("button",{onClick:()=>c({...t,carColor:n.id}),className:"w-8 h-8 rounded-full border-2 transition-all cursor-pointer shadow-sm "+(t?.carColor===n.id?"border-red-500 scale-110 shadow-md ring-2 ring-red-500/20":"border-slate-200 dark:border-slate-600 hover:scale-105"),style:{backgroundColor:n.hex},title:n.name,type:"button","aria-label":`Seleccionar color ${n.name}`},n.id))})]}):null})()]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carName",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carName","Nombre del coche")}),e.jsx("input",{id:"carName",name:"carName",type:"text",value:x?.name||t?.carName||"",onChange:s=>{const n=s.target.value;c({...t,carName:n}),u&&d(u,{name:n})},placeholder:a("settings.carNamePlaceholder","Ej: Mi BYD Seal"),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carVin",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.vin","VIN asociado")}),e.jsxs("select",{id:"carVin",name:"carVin",value:x?.vin||"",onChange:s=>(n=>{if(!u)return;const m=n||void 0;m&&g.forEach(h=>{h.id!==u&&h.vin===m&&d(h.id,{vin:void 0,connectorType:void 0})}),d(u,{vin:m,connectorType:m?"pybyd":void 0})})(s.target.value),disabled:!u||l&&b.length===0,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 font-mono text-sm disabled:opacity-50",children:[e.jsx("option",{value:"",children:a("settings.vinNone","Sin VIN asociado")}),b.map(s=>e.jsx("option",{value:s.vin,children:s.label},s.vin))]}),i.length>1&&e.jsxs("div",{className:"mt-4",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.otherVehicles","Otros vehículos en tu cuenta")}),e.jsx("div",{className:"space-y-2",children:i.filter(s=>s.vin!==x?.vin).map(s=>e.jsxs("div",{className:"flex items-center justify-between bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700",children:[e.jsx("span",{className:"text-sm font-mono text-slate-700 dark:text-slate-300",children:s.vin}),e.jsx("button",{type:"button",disabled:r===s.vin,onClick:()=>(async n=>{if(confirm(`¿Estás seguro de que quieres desvincular y borrar de la nube el vehículo ${n}? Esta acción eliminará permanentemente su historial si no hiciste copia en Drive.`)){o(n);try{const m=ye(void 0,"europe-west1");await Ne(m,"bydDetachVehicleV2")({vin:n}),R.success(a("settings.vehicleDetached","Vehículo desvinculado correctamente")),g.forEach(v=>{v.vin===n&&d(v.id,{vin:void 0,connectorType:void 0})})}catch(m){F.error("Error detaching vehicle:",m),R.error(m?.message||"Error al desvincular el vehículo")}finally{o(null)}}})(s.vin),className:"text-xs font-medium text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 disabled:opacity-50",children:r===s.vin?a("common.loading","Cargando..."):a("settings.detachVehicle","Desasociar de mi cuenta")})]},s.vin))})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"licensePlate",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.licensePlate")}),e.jsx("input",{id:"licensePlate",name:"licensePlate",type:"text",value:t?.licensePlate||"",onChange:s=>c({...t,licensePlate:s.target.value.toUpperCase()}),placeholder:"1234ABC",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 uppercase"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"batterySize",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.batterySize")}),e.jsx("input",{id:"batterySize",name:"batterySize",type:"number",step:"0.01",value:t?.batterySize||0,onChange:s=>c({...t,batterySize:parseFloat(s.target.value)||0}),onBlur:async()=>{if(x?.vin)try{const s=V(_,"bydVehicles",x.vin),n=typeof t.batterySize=="string"?parseFloat(t.batterySize):t.batterySize||0;if(!n||n<=0)return;await Z(s,{batteryCapacity:n,lastBatteryCapacity:n})}catch(s){F.error("Error syncing battery capacity:",s)}},className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]})]})},Le=()=>{const{t:a}=w(),{settings:t,updateSettings:c}=z(),{stats:x,aiSoH:d}=ae(),[u,g]=f.useState(!1),i=x?.summary?.sohData,l=t?.sohMode||"manual";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:a("settings.sohMode")}),e.jsx("div",{className:"flex gap-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",role:"radiogroup","aria-label":a("settings.sohMode"),children:["manual","calculated","ai"].map(r=>e.jsx("button",{role:"radio","aria-checked":l===r,onClick:()=>{r!=="calculated"||t.mfgDate||g(!0),c({...t,sohMode:r})},className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(l===r?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:r==="ai"?"SoH IA":a(`settings.soh${r.charAt(0).toUpperCase()+r.slice(1)}`)},r))}),l==="manual"?e.jsxs("div",{className:"space-y-3",children:[e.jsx("label",{htmlFor:"soh",className:"sr-only",children:a("settings.sohMode")}),e.jsx("input",{id:"soh",name:"soh","aria-label":a("settings.sohMode"),type:"number",min:"0",max:"100",value:t?.soh||100,onChange:r=>c({...t,soh:parseInt(r.target.value)||100}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"}),e.jsxs("button",{onClick:()=>g(!0),className:"w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(se,{className:"w-4 h-4 text-slate-400"}),e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-400",children:a("settings.mfgDate")})]}),e.jsx("span",{className:"text-xs font-bold text-slate-700 dark:text-slate-300",children:t.mfgDateDisplay||a("common.notSet","No definida")})]})]}):l==="calculated"?e.jsx("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-4 space-y-3 border border-slate-100 dark:border-slate-700/50",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.estimatedSoh")}),e.jsxs("span",{className:"text-lg font-bold text-emerald-600 dark:text-emerald-400",children:[i?.estimated_soh||100,"%"]})]})}):e.jsx("div",{className:"bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-4 space-y-3 border border-indigo-100 dark:border-indigo-800/30",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-indigo-600 dark:text-indigo-400 font-medium",children:a("settings.sohAi")}),e.jsxs("span",{className:"text-lg font-bold text-indigo-600 dark:text-indigo-400",children:[d?.toFixed(1)||100,"%"]})]})})]}),e.jsx(D.Suspense,{fallback:null,children:u&&e.jsx(Me,{isOpen:u,onClose:()=>g(!1),onSave:(r,o)=>{c({...t,mfgDate:r,mfgDateDisplay:o})},initialValue:t.mfgDateDisplay})})]})},Ie=()=>{const{t:a}=w(),{settings:t,updateSettings:c}=z(),{activeCar:x}=I(),{charges:d}=(function(){const{charges:r}=$();return{charges:r}})(),{avgElectricPrice:u,avgFuelPrice:g,electricStats:i,fuelStats:l}=f.useMemo(()=>{if(!d||d.length===0)return{avgElectricPrice:0,avgFuelPrice:0,electricStats:{count:0,total:0,kwh:0},fuelStats:{count:0,total:0,liters:0}};const r=d.filter(v=>!v.type||v.type==="electric"),o=d.filter(v=>v.type==="fuel"),b=r.reduce((v,j)=>v+(j.totalCost||0),0),s=r.reduce((v,j)=>v+(j.kwhCharged||0),0),n=s>0?b/s:0,m=o.reduce((v,j)=>v+(j.totalCost||0),0),h=o.reduce((v,j)=>v+(j.litersCharged||0),0);return{avgElectricPrice:n,avgFuelPrice:h>0?m/h:0,electricStats:{count:r.length,total:b,kwh:s},fuelStats:{count:o.length,total:m,liters:h}}},[d]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"electricPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:[a("settings.electricityPrice")," (€/kWh)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(r=>{const o=t.priceStrategy===r||!t.priceStrategy&&(r==="average"&&t.useCalculatedPrice||r==="custom"&&!t.useCalculatedPrice);return e.jsx("button",{onClick:()=>c({...t,priceStrategy:r,useCalculatedPrice:r==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(o?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:r!=="average"||d&&d.length!==0?"":a("settings.priceCalculatedNoData"),children:a(r==="custom"?"settings.priceCustom":r==="average"?"settings.priceCalculated":"settings.priceDynamics")},r)})}),t.priceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.priceStrategy!=="dynamic"&&e.jsx("input",{id:"electricPrice",name:"electricPrice",type:"number",step:"0.001",value:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?u.toFixed(3):t?.electricPrice||0,onChange:r=>c({...t,electricPrice:parseFloat(r.target.value)||0}),disabled:t.priceStrategy==="average"||t.useCalculatedPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.priceStrategy==="average"||t.useCalculatedPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?a("settings.priceCalculatedAuto"):"0.15"}),(t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice)&&(i.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfo",{count:i.count,total:i.total.toFixed(2),kwh:i.kwh.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")}))]}),x?.isHybrid&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"fuelPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:"⛽"}),a("settings.fuelPrice")," (€/L)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(r=>{const o=t.fuelPriceStrategy===r||!t.fuelPriceStrategy&&(r==="average"&&t.useCalculatedFuelPrice||r==="custom"&&!t.useCalculatedFuelPrice);return e.jsx("button",{onClick:()=>c({...t,fuelPriceStrategy:r,useCalculatedFuelPrice:r==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(o?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:r==="average"&&l.count===0?a("settings.priceCalculatedNoData"):"",children:a(r==="custom"?"settings.priceCustom":r==="average"?"settings.priceCalculated":"settings.priceDynamics")},r)})}),t.fuelPriceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.fuelPriceStrategy!=="dynamic"&&e.jsx("input",{id:"fuelPrice",name:"fuelPrice",type:"number",step:"0.01",value:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?g.toFixed(3):t?.fuelPrice||1.5,onChange:r=>c({...t,fuelPrice:parseFloat(r.target.value)||1.5}),disabled:t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?a("settings.priceCalculatedAuto"):"1.50"}),(t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice)&&(l.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfoFuel",{count:l.count,total:l.total.toFixed(2),liters:l.liters.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")})),(!t.fuelPriceStrategy||t.fuelPriceStrategy==="custom")&&!t.useCalculatedFuelPrice&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.fuelPriceHint")})]})]})},Ve=()=>{const{t:a}=w(),{settings:t,updateSettings:c}=z(),{cars:x}=I(),d=t.electricityTariff||"flat_24h",u=x.map(i=>i.vin).filter(i=>!!i).join(",");f.useEffect(()=>{if(!u)return;const i=J(Q());for(const l of u.split(","))Y(V(i,"bydVehicles",l),{electricityTariff:d},{merge:!0}).catch(()=>{})},[d,u]);const g="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{children:"⚡"}),a("settings.electricityTariff","Tarifa eléctrica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsx("div",{className:"flex gap-1 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["flat_24h","three_period","pvpc"].map(i=>{const l=d===i,r={flat_24h:a("settings.tariff24h","24h"),three_period:a("settings.tariff3periods","3 tramos"),pvpc:a("settings.tariffPVPC","PVPC")};return e.jsx("button",{onClick:()=>{c({...t,electricityTariff:i})},disabled:!1,className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(l?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:r[i]},i)})}),d==="flat_24h"&&e.jsxs("div",{children:[e.jsx("label",{htmlFor:"flatRatePrice",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.tariff24hPrice","Precio (€/kWh)")}),e.jsx("input",{id:"flatRatePrice",name:"flatRatePrice",type:"number",step:"0.001",value:t.flatRatePrice??.15,onFocus:i=>i.target.select(),onChange:i=>c({...t,flatRatePrice:parseFloat(i.target.value)||0}),className:g,placeholder:"0.15"}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:a("settings.tariff24hDesc","Mismo precio las 24h, todos los días.")})]}),d==="three_period"&&e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"bg-emerald-50 dark:bg-emerald-900/10 rounded-lg p-2.5 border border-emerald-200 dark:border-emerald-800/30",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("label",{htmlFor:"valleyPrice",className:"text-xs font-semibold text-emerald-700 dark:text-emerald-300",children:a("settings.valleyPrice","Valle")}),e.jsx("span",{className:"text-[10px] text-emerald-600 dark:text-emerald-400",children:a("settings.valleyHours","L-V 0-8h, S-D 24h")})]}),e.jsx("input",{id:"valleyPrice",name:"valleyPrice",type:"number",step:"0.001",value:t.valleyPrice??.08,onFocus:i=>i.target.select(),onChange:i=>c({...t,valleyPrice:parseFloat(i.target.value)||0}),className:g,placeholder:"0.08"})]}),e.jsxs("div",{className:"bg-amber-50 dark:bg-amber-900/10 rounded-lg p-2.5 border border-amber-200 dark:border-amber-800/30",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("label",{htmlFor:"flatPrice",className:"text-xs font-semibold text-amber-700 dark:text-amber-300",children:a("settings.flatPrice","Llano")}),e.jsx("span",{className:"text-[10px] text-amber-600 dark:text-amber-400",children:a("settings.flatHours","L-V 8-10h, 14-18h, 22-24h")})]}),e.jsx("input",{id:"flatPrice",name:"flatPrice",type:"number",step:"0.001",value:t.flatPrice??.12,onFocus:i=>i.target.select(),onChange:i=>c({...t,flatPrice:parseFloat(i.target.value)||0}),className:g,placeholder:"0.12"})]}),e.jsxs("div",{className:"bg-red-50 dark:bg-red-900/10 rounded-lg p-2.5 border border-red-200 dark:border-red-800/30",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("label",{htmlFor:"peakPrice",className:"text-xs font-semibold text-red-700 dark:text-red-300",children:a("settings.peakPrice","Punta")}),e.jsx("span",{className:"text-[10px] text-red-600 dark:text-red-400",children:a("settings.peakHours","L-V 10-14h, 18-22h")})]}),e.jsx("input",{id:"peakPrice",name:"peakPrice",type:"number",step:"0.001",value:t.peakPrice??.18,onFocus:i=>i.target.select(),onChange:i=>c({...t,peakPrice:parseFloat(i.target.value)||0}),className:g,placeholder:"0.18"})]})]}),d==="pvpc"&&e.jsxs("div",{className:"bg-blue-50 dark:bg-blue-900/10 rounded-lg p-3 border border-blue-200 dark:border-blue-800/30",children:[e.jsx("p",{className:"text-xs text-blue-700 dark:text-blue-300",children:a("settings.pvpcDesc","Precio regulado horario indexado al mercado mayorista (ESIOS). Los precios se obtienen automáticamente al iniciar una carga y se actualizan diariamente.")}),e.jsx("p",{className:"text-[10px] text-blue-500 dark:text-blue-400 mt-2",children:a("settings.pvpcNote","El precio por kWh se calcula según la hora de inicio y duración de cada carga, usando los precios horarios oficiales de REE.")})]})]})]})},Re=()=>{const{t:a}=w(),{settings:t,updateSettings:c}=z(),{charges:x}=$(),d=f.useMemo(()=>{const r=t.batterySize,o=typeof r=="string"?parseFloat(r):Number(r);return o>0?o:0},[t.batterySize]),u=f.useMemo(()=>{if(!d||!x?.length)return{};const r={};for(const o of t.chargerTypes??[]){const b=Se(x,d,o.id);b&&(r[o.id]=b)}return r},[x,d,t.chargerTypes]),g=f.useCallback((r,o,b)=>{const s=[...t.chargerTypes||[]];s[r]={...s[r],[o]:b},c({...t,chargerTypes:s})},[t,c]),i=f.useCallback(()=>{const r={id:`custom_${Date.now()}`,name:a("settings.newChargerType"),speedKw:7.4,efficiency:.9},o=[...t.chargerTypes||[],r];c({...t,chargerTypes:o})},[t,c,a]),l=f.useCallback(r=>{const o=t.chargerTypes?.[r]?.id,b=(t.chargerTypes||[]).filter((n,m)=>m!==r),s=o?Array.from(new Set([...t.deletedChargerIds||[],o])):t.deletedChargerIds||[];c({...t,chargerTypes:b,deletedChargerIds:s})},[t,c]);return e.jsx("div",{className:"space-y-4",children:e.jsxs("div",{className:"space-y-3",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:L},children:e.jsx(re,{className:"w-4 h-4"})}),a("settings.chargerTypes")]}),(t?.chargerTypes||[]).map((r,o)=>{const b=`charger_${o}_name`,s=`charger_${o}_speed`,n=`charger_${o}_efficiency`,m=u[r.id],h=r?.efficiency||0,v=m&&Math.abs(m.value-h)>=.01,j=r.id===le;return e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("label",{htmlFor:b,className:"sr-only",children:a("settings.chargerName")}),e.jsx("input",{id:b,name:b,type:"text",value:r?.name||"",onChange:p=>g(o,"name",p.target.value),className:"flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:a("settings.chargerName")}),j?e.jsx("span",{className:"shrink-0 text-[10px] font-semibold px-2 py-1 rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",children:"🏠 240V"}):e.jsx("button",{onClick:()=>l(o),className:"p-2 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors",title:a("settings.deleteChargerType"),"aria-label":a("settings.deleteChargerType"),children:e.jsx(Pe,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:s,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerSpeed")}),e.jsx("input",{id:s,name:s,type:"number",step:"0.1",value:r?.speedKw||0,onChange:p=>g(o,"speedKw",parseFloat(p.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:n,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerEfficiency")}),e.jsx("input",{id:n,name:n,type:"number",step:"0.01",min:"0",max:"1",value:r?.efficiency||0,onChange:p=>g(o,"efficiency",parseFloat(p.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]}),v&&e.jsxs("div",{className:"flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg px-3 py-1.5",children:[e.jsxs("span",{className:"text-xs text-amber-700 dark:text-amber-300",children:[a("settings.inferredEfficiency"),": ",e.jsxs("strong",{children:[(100*m.value).toFixed(1),"%"]}),e.jsxs("span",{className:"text-amber-500 dark:text-amber-400 ml-1",children:["(",m.sampleCount," ",a("settings.inferredCharges"),")"]})]}),e.jsx("button",{onClick:()=>g(o,"efficiency",m.value),className:"text-xs font-medium text-amber-700 dark:text-amber-300 hover:text-amber-900 dark:hover:text-amber-100 underline underline-offset-2 ml-2",children:a("settings.applyInferred")})]})]},r.id)}),e.jsxs("button",{onClick:i,className:"w-full py-2 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:border-slate-400 dark:hover:border-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors text-sm",children:["+ ",a("settings.addChargerType")]})]})})},_e=()=>{const{t:a}=w(),{settings:t,updateSettings:c}=z();return e.jsx("div",{className:"space-y-4",children:e.jsxs("div",{className:"space-y-3",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:L},children:"⚡"}),a("settings.homeCharging","Carga Doméstica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"homeChargerRating",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.chargerRating","Potencia del Cargador (Amperios)")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{id:"homeChargerRating",name:"homeChargerRating",type:"number",value:t.homeChargerRating??8,onFocus:x=>x.target.select(),onChange:x=>c({...t,homeChargerRating:parseInt(x.target.value)||0}),className:"w-20 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"}),e.jsxs("span",{className:"text-xs text-slate-400",children:["≈ ",(230*(t.homeChargerRating??8)/1e3).toFixed(1)," kW"]})]}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:"8A (1.8kW), 10A (2.3kW), 16A (3.7kW), 32A (7.4kW)"})]}),e.jsx(Ve,{})]})]})})},He=[{code:"ES",name:"España"},{code:"DE",name:"Germany"},{code:"FR",name:"France"},{code:"IT",name:"Italy"},{code:"NL",name:"Netherlands"},{code:"BE",name:"Belgium"},{code:"AT",name:"Austria"},{code:"PT",name:"Portugal"},{code:"SE",name:"Sweden"},{code:"NO",name:"Norway"},{code:"DK",name:"Denmark"},{code:"FI",name:"Finland"},{code:"GB",name:"United Kingdom"},{code:"IE",name:"Ireland"},{code:"CH",name:"Switzerland"},{code:"PL",name:"Poland"},{code:"CZ",name:"Czech Republic"},{code:"HU",name:"Hungary"}],We=({username:a,password:t,countryCode:c,controlPin:x,isLoading:d,isActivatingPremium:u=!1,onUsernameChange:g,onPasswordChange:i,onCountryCodeChange:l,onControlPinChange:r,onConnect:o})=>{const{t:b}=w();return e.jsxs("div",{className:"connection-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-username",children:b("settings.emailLabel")}),e.jsx("input",{id:"byd-username",type:"email",value:a,onChange:s=>g(s.target.value),placeholder:b("settings.emailPlaceholder"),disabled:d})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-password",children:b("settings.passwordLabel")}),e.jsx("input",{id:"byd-password",type:"password",value:t,onChange:s=>i(s.target.value),placeholder:"••••••••",disabled:d})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-country",children:b("settings.countryLabel")}),e.jsx("select",{id:"byd-country",value:c,onChange:s=>l(s.target.value),disabled:d,children:He.map(s=>e.jsx("option",{value:s.code,children:s.name},s.code))})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-pin",children:b("settings.pinLabel")}),e.jsx("input",{id:"byd-pin",type:"password",value:x,onChange:s=>r(s.target.value),placeholder:"1234",maxLength:6,disabled:d}),e.jsx("span",{className:"form-hint",children:"Opcional. Necesario para algunas funciones avanzadas."})]}),e.jsx("button",{className:"btn-connect",onClick:o,disabled:u||d||!a||!t,children:u?b("settings.activatingPremium"):d?"Conectando...":b("byd.connect.submit","Conectar con el vehículo")})]})},Ue=({connectedVin:a})=>{const{t}=w(),[c,x]=f.useState(100),[d,u]=f.useState(!0),[g,i]=f.useState(!0),[l,r]=f.useState(!1);f.useEffect(()=>{X(V(_,"bydVehicles",a,"preferences","charging")).then(n=>{if(n.exists()){const m=n.data();typeof m.targetSoc=="number"&&x(m.targetSoc),typeof m.notifyNearTarget=="boolean"&&u(m.notifyNearTarget),typeof m.notifyAtTarget=="boolean"&&i(m.notifyAtTarget)}}).catch(n=>F.warn("[ChargeTargetSettings] Could not read prefs:",n))},[a]);const o=async(n,m,h)=>{r(!0);try{await ne(a,n,{notifyNearTarget:m,notifyAtTarget:h}),A.success(t("charging.targetSet","Objetivo de carga actualizado"))}catch(v){F.error("[ChargeTargetSettings] persist error:",v),A.error(t("charging.targetSetError","No se pudo enviar al vehículo"))}finally{r(!1)}},b=()=>{o(c,d,g)},s=c>=100;return e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:t("charging.targetSoc","Objetivo de carga")}),e.jsxs("div",{className:"mt-2 flex items-center gap-3",children:[e.jsx("input",{type:"range",min:50,max:100,step:5,value:c,disabled:l,onChange:n=>{x(Number(n.target.value))},onMouseUp:b,onTouchEnd:b,className:"flex-1 accent-emerald-500 disabled:opacity-50","aria-label":t("charging.targetSoc","Objetivo de carga")}),e.jsx("span",{className:"text-sm font-semibold text-slate-700 dark:text-slate-200 min-w-[5rem] text-right",children:c>=100?t("charging.targetFull","Completa (sin avisos)"):`${c}%`})]}),e.jsxs("div",{className:"mt-3 space-y-2 "+(s?"opacity-40 pointer-events-none":""),children:[e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-300",children:t("charging.notifyNearLabel","Avisar cerca del objetivo")}),e.jsx("input",{type:"checkbox",checked:d,onChange:n=>{const m=n.target.checked;u(m),o(c,m,g)},disabled:s||l,className:"toggle-checkbox w-11 h-6 cursor-pointer"})]}),e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-300",children:t("charging.notifyAtLabel","Avisar al alcanzar el objetivo")}),e.jsx("input",{type:"checkbox",checked:g,onChange:n=>{const m=n.target.checked;i(m),o(c,d,m)},disabled:s||l,className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})]})]})},Ge=D.lazy(()=>H(()=>import("./chunk-CbI2QISs.js"),__vite__mapDeps([14,1,2,3,4,5,6,7,15,8]),import.meta.url).then(a=>({default:a.AbrpHelpModal}))),Oe=D.lazy(()=>H(()=>import("./chunk-DlRd8Lq5.js"),__vite__mapDeps([16,1,2,3,4,5,6,7,15,8]),import.meta.url).then(a=>({default:a.SecondaryAccountModal}))),$e=({connectedVin:a,connectedVehicles:t,isLoading:c,autoRegisterCharges:x,heartbeatEnabled:d,hasAbrpToken:u,abrpToken:g,abrpSaving:i,onDisconnect:l,onRefreshVehicles:r,onAutoRegisterChange:o,onHeartbeatChange:b,onAbrpTokenChange:s,onSaveAbrpToken:n,onConnectionTap:m})=>{const{t:h}=w(),[v,j]=f.useState(!1),[p,y]=f.useState(!1),[k,P]=f.useState(""),[N,E]=f.useState(!1),ee=ie(a),M=ee?.controlPinStatus;return e.jsxs("div",{className:"mb-4",children:[e.jsxs("div",{className:"connection-status connected",style:{marginBottom:"1rem",cursor:"pointer",userSelect:"none"},onClick:m,title:"Toca 10 veces para API Dump",children:[e.jsx("span",{className:"status-icon",children:"✓"}),e.jsxs("div",{className:"status-info",children:[e.jsx("strong",{children:"Conectado"}),e.jsx("span",{className:"vin",children:a}),(()=>{const C=t.find(S=>S.vin===a)??t[0];return C?e.jsx("span",{className:"vehicle-name",children:C.name||C.model}):null})()]})]}),e.jsx("button",{className:"btn-refresh w-full mb-2",onClick:r,disabled:c,children:"Actualizar coches"}),e.jsx("button",{className:"btn-disconnect w-full",onClick:l,disabled:c,children:"Desconectar"}),e.jsxs("button",{onClick:()=>y(!0),className:"mt-3 w-full text-left text-xs text-blue-600 dark:text-blue-400 hover:underline",children:["💡 ",h("secondaryAccount.reminder","Recuerda usar una cuenta secundaria de BYD — toca aquí para ver cómo crearla")]}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:h("charges.autoRegisterTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:h("charges.autoRegisterDesc")})]}),e.jsx("input",{type:"checkbox",checked:x,onChange:C=>{const S=C.target.checked;o(S),localStorage.setItem("byd_auto_register_charges",String(S)),A.success(h(S?"charges.autoRegisterEnabled":"charges.autoRegisterDisabled"))},className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:h("charges.locationWatchTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:h("charges.locationWatchDesc")})]}),e.jsx("input",{type:"checkbox",checked:d,onChange:C=>(async S=>{b(S);try{await Z(V(_,"bydVehicles",a),{heartbeatEnabled:S}),A.success(h(S?"charges.locationWatchEnabled":"charges.locationWatchDisabled"))}catch(W){F.error("Error updating heartbeatEnabled:",W),b(!S),A.error(h("errors.genericWithMessage",{message:W?.message||h("errors.cannotSave")}))}})(C.target.checked),className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx(Ue,{connectedVin:a}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:h("settings.pin.title","PIN de control")}),M==="set"&&e.jsxs("span",{className:"text-xs font-medium text-green-600 dark:text-green-400",children:["✓ ",h("settings.pin.statusSet","Configurado")]}),M==="invalid"&&e.jsxs("span",{className:"text-xs font-medium text-red-600 dark:text-red-400",children:["✗ ",h("settings.pin.statusInvalid","Incorrecto")]}),(M==="not_set"||M===void 0)&&e.jsx("span",{className:"text-xs font-medium text-amber-600 dark:text-amber-400",children:h("settings.pin.statusNotSet","Sin configurar")})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:h("settings.pin.desc","Necesario para bloquear/desbloquear y controlar el clima. Sin él las acciones rápidas quedan desactivadas.")}),M==="invalid"&&e.jsx("div",{className:"mb-3 text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg p-2",children:h("settings.pin.invalidWarning","El PIN guardado es incorrecto. Introdúcelo de nuevo.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:k,onChange:C=>P(C.target.value.replace(/\D/g,"").slice(0,6)),placeholder:M==="set"?h("settings.pin.placeholderChange","Escribe el PIN para cambiarlo"):h("settings.pin.placeholder","Ej. 123456"),inputMode:"numeric",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:async()=>{const C=k.trim();if(C){E(!0);try{await oe(a,C),P(""),A.success(h("settings.pin.saved","PIN de control guardado"))}catch(S){F.error("[BydIntegrationSettings] Error saving PIN:",S),A.error(h("errors.genericWithMessage",{message:S?.message||h("errors.cannotSave")}))}finally{E(!1)}}},disabled:N||!k.trim(),className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:N?"...":h("common.save","Guardar")})]})]}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:"ABRP — A Better Route Planner"}),e.jsx("button",{onClick:()=>j(!0),"aria-label":h("abrp.help.buttonLabel","Ayuda para obtener el token de ABRP"),className:"w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-blue-100 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",children:"?"})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:h("abrp.tokenDesc","Introduce tu token de ABRP para enviar telemetría en tiempo real.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:g,onChange:C=>s(C.target.value),placeholder:u?h("abrp.tokenPlaceholderSet","Token guardado — escribe uno nuevo para reemplazar"):"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:n,disabled:i,className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:i?"...":h("common.save","Guardar")})]}),u&&!g&&e.jsxs("div",{className:"mt-2 text-xs text-green-600 dark:text-green-400",children:["✓ ",h("abrp.telemetryActive","Telemetría ABRP activa")]})]}),e.jsxs(D.Suspense,{fallback:null,children:[v&&e.jsx(Ge,{isOpen:v,onClose:()=>j(!1)}),p&&e.jsx(Oe,{isOpen:p,onClose:()=>y(!1)})]})]})},qe=({connectedVin:a,debugDump:t,onClose:c})=>{const{t:x}=w();return e.jsxs("div",{className:"diagnostic-display",style:{marginTop:"1rem"},children:[e.jsxs("h5",{children:["API Dump (Raw)",e.jsxs("div",{className:"dump-actions",children:[e.jsx("button",{className:"btn-copy",onClick:()=>{navigator.clipboard.writeText(JSON.stringify(t,null,2)),A.success(x("settings.debug.dumpCopied"))},children:"📋 Copiar"}),e.jsx("button",{className:"btn-close",onClick:c,children:"✕"})]})]}),e.jsx("div",{className:"dump-info",children:e.jsxs("small",{children:["Guardado en Firestore: ",e.jsxs("code",{children:["bydVehicles/",a,"/debug"]})]})}),e.jsx("pre",{className:"diagnostic-json",children:JSON.stringify(t,null,2)})]})},Ke=({onConnectionChange:a})=>{const{t}=w(),{cars:c,activeCar:x,addCar:d,updateCar:u}=I(),g=K.getPlatform()!=="ios",i=x?.connectorType==="pybyd"&&x.vin?x.vin:null,l=De(a,i),r=f.useCallback(o=>{o.length!==0&&(o.forEach(({vin:b,target:s,vehicle:n})=>{c.forEach(m=>{m.vin===b&&m.id!==s&&u(m.id,{vin:void 0,connectorType:void 0})}),s==="new"?d({name:n.name||n.model||"Mi coche",vin:b,type:"ev",isHybrid:!1,connectorType:"pybyd"}):u(s,{vin:b,connectorType:"pybyd"})}),l.selectVehiclesSilent(o[0].vin))},[c,d,u,l]);return e.jsxs("div",{className:"byd-settings",children:[e.jsxs("div",{className:"settings-section",children:[e.jsxs("h3",{className:"settings-title",children:[e.jsx("span",{className:"icon",children:"🚗"}),t("byd.settings.sectionTitle","Conexión directa con el vehículo")]}),i&&e.jsx($e,{connectedVin:i,connectedVehicles:l.connectedVehicles,isLoading:l.isLoading,autoRegisterCharges:l.autoRegisterCharges,heartbeatEnabled:l.heartbeatEnabled,hasAbrpToken:l.hasAbrpToken,abrpToken:l.abrpToken,abrpSaving:l.abrpSaving,onDisconnect:l.handleDisconnect,onRefreshVehicles:l.handleRefreshVehicles,onAutoRegisterChange:l.setAutoRegisterCharges,onHeartbeatChange:l.setHeartbeatEnabled,onAbrpTokenChange:l.setAbrpToken,onSaveAbrpToken:l.handleSaveAbrpToken,onConnectionTap:l.handleConnectionTap}),l.error&&e.jsxs("div",{className:"message error",children:[e.jsx("span",{className:"icon",children:"⚠️"}),l.error]}),l.success&&e.jsxs("div",{className:"message success",children:[e.jsx("span",{className:"icon",children:"✓"}),l.success]}),!i&&e.jsx(We,{username:l.username,password:l.password,countryCode:l.countryCode,controlPin:l.controlPin,isLoading:l.isLoading,isActivatingPremium:l.isActivatingPremium,onUsernameChange:l.setUsername,onPasswordChange:l.setPassword,onCountryCodeChange:l.setCountryCode,onControlPinChange:l.setControlPin,onConnect:l.handleConnect}),g&&i&&l.debugDump&&e.jsx(qe,{connectedVin:i,debugDump:l.debugDump,onClose:l.clearDebugDump})]}),l.pendingVehicles&&e.jsx(Ae,{vehicles:l.pendingVehicles,existingCars:c.map(o=>({id:o.id,name:o.name,vin:o.vin})),onConfirm:r,onCancel:l.cancelVehicleSelection}),e.jsx("style",{children:`
                .byd-settings {
                    padding: 1rem;
                }

                .settings-section {
                    background: #ffffff;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .dark .settings-section {
                    background: #1e293b;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }

                .settings-title {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 0 0.5rem 0;
                    font-size: 1.25rem;
                    color: #1f2937;
                }

                .dark .settings-title {
                    color: #f1f5f9;
                }

                .settings-title .icon {
                    font-size: 1.5rem;
                }

                .settings-description {
                    color: #6b7280;
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }

                .dark .settings-description {
                    color: #94a3b8;
                }

                .connection-status {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }

                .connection-status.connected {
                    background: #dcfce7;
                    border: 1px solid #4ade80;
                }

                .dark .connection-status.connected {
                    background: rgba(34, 197, 94, 0.15);
                    border: 1px solid #22c55e;
                }

                .status-icon {
                    font-size: 1.5rem;
                    color: #22c55e;
                }

                .status-info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                    min-width: 0;
                }

                .status-info strong {
                    color: #166534;
                }

                .dark .status-info strong {
                    color: #4ade80;
                }

                .status-info .vin {
                    font-family: monospace;
                    font-size: 0.8rem;
                    color: #6b7280;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .dark .status-info .vin {
                    color: #94a3b8;
                }

                .status-info .vehicle-name {
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .status-info .vehicle-name {
                    color: #94a3b8;
                }

                .message {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }

                .message.error {
                    background: #fee2e2;
                    color: #dc2626;
                    border: 1px solid #f87171;
                }

                .dark .message.error {
                    background: rgba(220, 38, 38, 0.15);
                    color: #f87171;
                    border: 1px solid rgba(248, 113, 113, 0.3);
                }

                .message.success {
                    background: #dcfce7;
                    color: #16a34a;
                    border: 1px solid #4ade80;
                }

                .dark .message.success {
                    background: rgba(34, 197, 94, 0.15);
                    color: #4ade80;
                    border: 1px solid rgba(74, 222, 128, 0.3);
                }

                .connection-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .form-group label {
                    font-size: 0.9rem;
                    font-weight: 500;
                    color: #374151;
                }

                .dark .form-group label {
                    color: #e2e8f0;
                }

                .form-group input,
                .form-group select {
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 1rem;
                    background: #ffffff;
                    color: #1f2937;
                }

                .dark .form-group input,
                .dark .form-group select {
                    background: #0f172a;
                    border-color: #334155;
                    color: #f1f5f9;
                }

                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                }

                .form-group input::placeholder {
                    color: #9ca3af;
                }

                .dark .form-group input::placeholder {
                    color: #64748b;
                }

                .form-hint {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .form-hint {
                    color: #94a3b8;
                }

                .btn-connect,
                .btn-disconnect,
                .btn-refresh {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                    text-align: center;
                }

                .btn-refresh {
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    color: #374151;
                }

                .dark .btn-refresh {
                    background: #334155;
                    border: 1px solid #475569;
                    color: #e2e8f0;
                }

                .btn-refresh:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-refresh:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-refresh:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .btn-connect {
                    background: #3b82f6;
                    color: white;
                }

                .btn-connect:hover:not(:disabled) {
                    background: #2563eb;
                }

                .btn-connect:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }

                .dark .btn-connect:disabled {
                    background: #475569;
                }

                .btn-disconnect {
                    background: #ef4444;
                    color: white;
                    flex-shrink: 0;
                }

                .btn-disconnect:hover:not(:disabled) {
                    background: #dc2626;
                }

                .connected-actions {
                    margin-top: 1.5rem;
                }

                .connected-actions h4 {
                    margin: 0 0 1rem 0;
                    font-size: 1rem;
                    color: #374151;
                }

                .dark .connected-actions h4 {
                    color: #e2e8f0;
                }

                .action-buttons {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }

                .btn-action {
                    padding: 0.5rem 1rem;
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    color: #374151;
                }

                .dark .btn-action {
                    background: #334155;
                    border-color: #475569;
                    color: #e2e8f0;
                }

                .btn-action:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-action:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-action:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .data-display {
                    background: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }

                .dark .data-display {
                    background: #0f172a;
                    border-color: #334155;
                }

                .data-display h5 {
                    margin: 0 0 0.75rem 0;
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .data-display h5 {
                    color: #94a3b8;
                }

                .data-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }

                .data-item {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .data-item .label {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .data-item .label {
                    color: #94a3b8;
                }

                .data-item .value {
                    font-size: 1rem;
                    font-weight: 500;
                    color: #1f2937;
                }

                .dark .data-item .value {
                    color: #f1f5f9;
                }

                .btn-map {
                    display: inline-block;
                    margin-top: 0.75rem;
                    padding: 0.5rem 1rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-size: 0.9rem;
                }

                .btn-map:hover {
                    background: #2563eb;
                }

                .diagnostic-display {
                    margin-top: 1rem;
                }

                .diagnostic-display h5 {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 0 0 0.5rem 0;
                    color: #374151;
                }

                .dark .diagnostic-display h5 {
                    color: #e2e8f0;
                }

                .btn-close {
                    background: none;
                    border: none;
                    font-size: 1.25rem;
                    cursor: pointer;
                    color: #6b7280;
                }

                .dark .btn-close {
                    color: #94a3b8;
                }

                .btn-close:hover {
                    color: #374151;
                }

                .dark .btn-close:hover {
                    color: #e2e8f0;
                }

                .diagnostic-json {
                    background: #1e293b;
                    color: #a3e635;
                    padding: 1rem;
                    border-radius: 8px;
                    font-size: 0.75rem;
                    overflow-x: auto;
                    max-height: 400px;
                }
            `})]})},Ze=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"white"}),e.jsx("path",{d:"M0,0 L0,160 L427,480 L640,480 L640,320 L213,0 Z",fill:"#0092E6"})]}),Je=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#FFED00"}),e.jsx("rect",{y:"48",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"144",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"240",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"336",width:"640",height:"48",fill:"#DA121A"})]}),Qe=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#d52b1e",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#fff",d:"M0 200h640v80H0z"}),e.jsx("path",{fill:"#fff",d:"M280 0h80v480h-80z"}),e.jsx("path",{fill:"#009b48",d:"m0 0 640 480h-80L0 80z"}),e.jsx("path",{fill:"#009b48",d:"M560 0 0 420v60L640 60V0z"})]}),Ye=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#AA151B"}),e.jsx("rect",{width:"640",height:"240",y:"120",fill:"#F1BF00"})]}),Xe=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#012169",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#FFF",d:"M75 0 0 53v28L640 480h-87l-75-53v28L0 0h75zM640 0v53L0 480v-28L640 0z"}),e.jsx("path",{fill:"#C8102E",d:"m424 286 216 144v50L424 286zm-208-92L0 50V0l216 194zM0 480l216-144v-50L0 480zm640 0L424 286l216-144v144z"}),e.jsx("path",{fill:"#FFF",d:"M250 0h140v480H250zM0 170h640v140H0z"}),e.jsx("path",{fill:"#C8102E",d:"M280 0h80v480h-80zM0 200h640v80H0z"})]}),et=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#C60C30"}),e.jsx("rect",{width:"240",height:"480",fill:"#006600"}),e.jsx("circle",{cx:"240",cy:"240",r:"80",fill:"#FFC400"}),e.jsx("circle",{cx:"240",cy:"240",r:"70",fill:"#FFF"}),e.jsx("path",{fill:"#006600",d:"M190 240 a50 50 0 0 1 100 0 h-10 a40 40 0 0 0 -80 0 z"}),e.jsx("rect",{x:"220",y:"190",width:"40",height:"50",fill:"#C60C30"})]}),tt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"213.3",height:"480",fill:"#002395"}),e.jsx("rect",{width:"213.3",height:"480",x:"213.3",fill:"#FFF"}),e.jsx("rect",{width:"213.4",height:"480",x:"426.7",fill:"#ED2939"})]}),at=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"213.3",height:"480",fill:"#009246"}),e.jsx("rect",{width:"213.3",height:"480",x:"213.3",fill:"#FFF"}),e.jsx("rect",{width:"213.4",height:"480",x:"426.7",fill:"#CE2B37"})]}),st=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"160",fill:"#000"}),e.jsx("rect",{width:"640",height:"160",y:"160",fill:"#DD0000"}),e.jsx("rect",{width:"640",height:"160",y:"320",fill:"#FFCE00"})]}),rt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"160",fill:"#AE1C28"}),e.jsx("rect",{width:"640",height:"160",y:"160",fill:"#FFF"}),e.jsx("rect",{width:"640",height:"160",y:"320",fill:"#21468B"})]}),lt=()=>{const{t:a,i18n:t}=w(),{settings:c,updateSettings:x}=z(),d=K.isNativePlatform(),[u,g]=f.useState(ce),[i,l]=f.useState(()=>localStorage.getItem("wear_complication_action")??"launch_app"),r=f.useCallback(s=>{localStorage.setItem("wear_complication_action",s),l(s)},[]);D.useEffect(()=>{de(!0)},[]);const o=f.useCallback(s=>{xe(s),g(s)},[]),b=f.useCallback(s=>{t.changeLanguage(s),me(s)},[t]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.language")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.language"),className:"grid grid-cols-5 gap-2",children:he.map(s=>e.jsxs("button",{role:"radio","aria-checked":t.language===s.code||t.language?.startsWith(s.code),onClick:()=>b(s.code),className:"py-2 rounded-xl text-xs font-semibold transition-colors flex flex-col items-center justify-center gap-1 border "+(t.language===s.code||t.language?.startsWith(s.code)?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),title:s.name,children:[e.jsx("span",{className:"inline-flex items-center justify-center",style:{width:"22px",height:"14px"},children:s.code==="gl"?e.jsx(Ze,{className:"w-full h-full rounded-sm"}):s.code==="ca"?e.jsx(Je,{className:"w-full h-full rounded-sm"}):s.code==="eu"?e.jsx(Qe,{className:"w-full h-full rounded-sm"}):s.code==="es"?e.jsx(Ye,{className:"w-full h-full rounded-sm"}):s.code==="en"?e.jsx(Xe,{className:"w-full h-full rounded-sm"}):s.code==="pt"?e.jsx(et,{className:"w-full h-full rounded-sm"}):s.code==="fr"?e.jsx(tt,{className:"w-full h-full rounded-sm"}):s.code==="it"?e.jsx(at,{className:"w-full h-full rounded-sm"}):s.code==="de"?e.jsx(st,{className:"w-full h-full rounded-sm"}):s.code==="nl"?e.jsx(rt,{className:"w-full h-full rounded-sm"}):e.jsx("span",{className:"text-lg leading-none",children:s.flag})}),e.jsx("span",{className:"leading-none",children:s.code.toUpperCase()})]},s.code))})]}),e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.theme")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.theme"),className:"flex gap-2",children:["auto","light","dark"].map(s=>e.jsx("button",{role:"radio","aria-checked":c?.theme===s,onClick:()=>x({...c,theme:s}),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(c?.theme===s?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:a(s==="auto"?"settings.themeAuto":s==="light"?"settings.themeLight":"settings.themeDark")},s))}),e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.customizeTabs")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:ge.filter(s=>s!=="overview").map(s=>{const n=(c.hiddenTabs||[]).includes(s);return e.jsxs("button",{onClick:()=>{const m=c.hiddenTabs||[],h=n?m.filter(v=>v!==s):[...m,s];x({...c,hiddenTabs:h})},className:"flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-colors border "+(n?"bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600":"byd-active-item"),children:[e.jsx("span",{children:a(`tabs.${s}`)}),n?e.jsx(Te,{className:"w-4 h-4"}):e.jsx(Fe,{className:"w-4 h-4"})]},s)})})]})]}),d&&e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.biometricMode","Método de verificación")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.biometricMode"),className:"flex gap-2",children:[{value:"biometric",label:a("settings.biometricModeHuella","🫆 Biométrico")},{value:"pin",label:a("settings.biometricModePin","🔢 PIN / Patrón")}].map(({value:s,label:n})=>e.jsx("button",{role:"radio","aria-checked":u===s,onClick:()=>o(s),className:"flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-colors border "+(u===s?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:n},s))}),e.jsx("p",{className:"text-xs text-slate-400 dark:text-slate-500 mt-2",children:u==="biometric"?a("settings.biometricModeHuellaDesc","Usa huella o reconocimiento facial al abrir la app"):a("settings.biometricModePinDesc","Usa el PIN o patrón del teléfono al abrir la app")})]}),d&&e.jsxs("div",{children:[e.jsxs("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:["⌚ ",a("settings.wearComplicationAction","Atajo del reloj")]}),e.jsx("p",{className:"text-xs text-slate-400 dark:text-slate-500 mb-2",children:a("settings.wearComplicationActionDesc","Qué hace el icono de la app en la esfera del reloj")}),e.jsx("div",{role:"radiogroup","aria-label":"Wear complication action",className:"flex gap-2",children:[{value:"launch_app",label:"📱 "+a("settings.wearActionLaunch","Abrir app")},{value:"unlock_car",label:"🔓 "+a("settings.wearActionUnlock","Abrir coche")}].map(({value:s,label:n})=>e.jsx("button",{role:"radio","aria-checked":i===s,onClick:()=>r(s),className:"flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-colors border "+(i===s?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:n},s))})]})]})},T=je("BluetoothTracker"),nt=()=>{const{t:a}=w(),{activeCarId:t,cars:c}=I(),[x,d]=f.useState([]),[u,g]=f.useState(""),[i,l]=f.useState(!1),[r,o]=f.useState(!1),[b,s]=f.useState(!1),[n,m]=f.useState(!1),h=c.find(p=>p.id===t);f.useEffect(()=>{v()},[t]);const v=async()=>{try{const p=await T.getTargetDevice();p.mac?(g(p.mac),l(!0)):(l(!1),g(""))}catch(p){console.error("Failed to load BT settings",p)}try{const p=await T.getActivityState();s(!!p.enabled)}catch(p){console.error("Failed to load activity settings",p)}},j=async p=>{const y=J(Q()),k=V(y,"bydVehicles",p,"preferences","integration");let N=(await X(k)).data()?.btSecurityToken;return N||(N=crypto.randomUUID(),await Y(k,{btSecurityToken:N},{merge:!0})),N};return h?.vin?e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-2",children:[e.jsx("div",{className:"p-2 rounded-xl",style:{backgroundColor:`${L}15`,color:L},children:e.jsx(ze,{className:"w-5 h-5"})}),e.jsx("h3",{className:"text-lg font-semibold text-slate-800 dark:text-white",children:a("settings.security.title","Seguridad y Bluetooth")})]}),e.jsx("p",{className:"text-sm text-slate-600 dark:text-slate-400",children:a("settings.security.btDescription","Al desconectar el Bluetooth del coche, la app intentará avisarte si las puertas o las ventanas se han quedado abiertas.")}),e.jsxs("div",{className:"flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700",children:[e.jsx("div",{className:"flex flex-col",children:e.jsx("span",{className:"font-medium text-slate-800 dark:text-white",children:a("settings.security.btAlerts","Avisos Bluetooth")})}),e.jsxs("label",{className:"relative inline-flex items-center cursor-pointer",children:[e.jsx("input",{type:"checkbox",className:"sr-only peer",checked:i,onChange:p=>(async y=>{if(!y)return await T.setTargetDevice({mac:"",vin:""}),l(!1),void g("");o(!0);try{const k=await T.getPairedDevices();d(k.devices||[]),l(!0)}catch(k){alert(k?.message||"Permiso denegado o Bluetooth no disponible"),l(!1)}finally{o(!1)}})(p.target.checked),disabled:r}),e.jsx("div",{className:"w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"})]})]}),i&&x.length>0&&e.jsxs("div",{className:"p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700 space-y-3",children:[e.jsx("label",{className:"block text-sm font-medium text-slate-700 dark:text-slate-300",children:a("settings.security.selectDevice","Selecciona el Bluetooth del coche:")}),e.jsxs("select",{className:"w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-lg p-2.5 text-slate-800 dark:text-white",value:u,onChange:p=>(async y=>{if(h?.vin){o(!0);try{const k=h.vin,P=await j(k);await T.setTargetDevice({mac:y,vin:k,token:P}),g(y)}catch(k){console.error(k),alert("Error guardando configuración")}finally{o(!1)}}})(p.target.value),disabled:r,children:[e.jsx("option",{value:"",children:a("common.select","Seleccionar...")}),x.map(p=>e.jsx("option",{value:p.mac,children:p.name||p.mac},p.mac))]})]}),e.jsxs("div",{className:"flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700",children:[e.jsxs("div",{className:"flex flex-col pr-3",children:[e.jsx("span",{className:"font-medium text-slate-800 dark:text-white",children:a("settings.security.activityTitle","Detección automática de viaje")}),e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.security.activityDescription","Intentará iniciar el viaje mucho más rápido aprovechando la conexión Bluetooth y el reconocimiento de actividad. No es imprescindible para detectar los viajes: solo mejora la rapidez de detección.")})]}),e.jsxs("label",{className:"relative inline-flex items-center cursor-pointer",children:[e.jsx("input",{type:"checkbox",className:"sr-only peer",checked:b,onChange:p=>(async y=>{if(y){if(h?.vin){m(!0);try{const k=h.vin,P=await j(k);await T.enableActivityRecognition({vin:k,token:P}),s(!0)}catch(k){alert(k?.message||a("settings.security.activityDenied","Permiso de actividad denegado")),s(!1)}finally{m(!1)}}}else{try{await T.disableActivityRecognition()}catch{}s(!1)}})(p.target.checked),disabled:n}),e.jsx("div",{className:"w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"})]})]})]}):null},B=({title:a,onBack:t,saveLabel:c,children:x})=>e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(q,{title:a,onClose:t}),e.jsx("div",{className:"space-y-6 mt-4",children:x}),e.jsx("button",{onClick:t,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:L},children:c})]})}),Dt=({onClose:a})=>{const{t}=w(),{closeModal:c}=G(),{googleSync:x}=O(),{cars:d,activeCarId:u,updateCar:g,addCar:i,setActiveCarId:l}=I(),{isNative:r}=be(),[o,b]=f.useState(null),[s,n]=f.useState(!1),[m,h]=f.useState(!1),v=()=>{a?a():c("settings")},j=()=>{b(null)};return o==="byd_api"?e.jsx(B,{title:"Direct API",onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Ke,{onConnectionChange:(p,y)=>{if(!p){const N=y?d.find(E=>E.vin===y):d.find(E=>E.connectorType==="pybyd");return void(N&&g(N.id,{vin:void 0,connectorType:void 0}))}if(!y)return;const k=d.find(N=>N.vin===y);if(k)return u!==k.id&&l(k.id),k.connectorType!=="pybyd"&&g(k.id,{connectorType:"pybyd"}),void d.forEach(N=>{N.id!==k.id&&N.vin===y&&g(N.id,{vin:void 0,connectorType:void 0})});const P=u?d.find(N=>N.id===u):void 0;P&&!P.vin?g(P.id,{vin:y,connectorType:"pybyd"}):i({name:"Mi coche",vin:y,type:"ev",isHybrid:!1,connectorType:"pybyd"})}})}):o==="sync"?e.jsx(B,{title:t("settings.googleDrive","Nube y Sincronización"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Ee,{googleSync:x})}):o==="car"?e.jsx(B,{title:t("settings.carConfiguration","Configuración del coche"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Be,{})}):o==="chargers"?e.jsx(B,{title:t("settings.chargerTypes","Tipos de cargadores"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Re,{})}):o==="home_charging"?e.jsx(B,{title:t("settings.homeCharging","Carga Doméstica"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(_e,{})}):o==="customization"?e.jsxs(B,{title:t("settings.personalization","Personalización"),onBack:j,saveLabel:t("common.save","Guardar"),children:[e.jsx(lt,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2",children:t("settings.electricityPrice","Precio electricidad")}),e.jsx(Ie,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Le,{}),r&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(nt,{})]})]}):s?e.jsx("div",{className:"fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-sm shadow-2xl p-6 relative",children:[e.jsx("h3",{className:"text-lg font-bold text-slate-900 dark:text-white mb-2",children:t("settings.deleteAccountConfirmTitle","¿Eliminar tu cuenta?")}),e.jsx("p",{className:"text-sm text-slate-600 dark:text-slate-400 mb-5 leading-relaxed",children:t("settings.deleteAccountConfirmBody","Esta acción es permanente. Se borrarán tu cuenta, la suscripción y la vinculación con tus vehículos. Esta acción no se puede deshacer.")}),e.jsxs("button",{onClick:async()=>{h(!0);try{await x.deleteAccount(),R.success(t("settings.deleteAccountDone","Cuenta eliminada"))}catch(p){const y=p;if(y.message&&/cancel|1001/i.test(y.message))return h(!1),void n(!1);R.error(t("settings.deleteAccountError","No se pudo eliminar la cuenta. Inténtalo de nuevo.")),h(!1),n(!1)}},disabled:m,className:"w-full py-3 rounded-xl font-bold text-white bg-red-600 hover:bg-red-700 transition-all active:scale-[0.98] disabled:opacity-60 flex items-center justify-center gap-2",children:[m&&e.jsx("div",{className:"w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"}),m?t("settings.deleteAccountDeleting","Eliminando..."):t("settings.deleteAccountConfirmCta","Sí, eliminar mi cuenta")]}),e.jsx("button",{onClick:()=>n(!1),disabled:m,className:"w-full mt-2 py-3 rounded-xl font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors disabled:opacity-60",children:t("common.cancel","Cancelar")})]})}):e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(q,{title:t("settings.title","Configuración"),onClose:v}),e.jsxs("div",{className:"space-y-3 mt-4",children:[r&&e.jsxs("button",{onClick:()=>b("byd_api"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"⚡"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:"Direct API"}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descBydApi","Conexión directa con tu vehículo")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("sync"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"☁️"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.googleDrive","Nube y Sincronización")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descCloudSync","Copia de seguridad en Google Drive")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("car"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🚗"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.carConfiguration","Configuración del coche")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descCarConfig","Modelo, VIN, matrícula y batería")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("chargers"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🔌"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.chargerTypes","Tipos de cargadores")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descChargerTypes","Velocidades y eficiencias de carga")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("home_charging"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🏠"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.homeCharging","Carga Doméstica")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descHomeCharging","Potencia y horarios de tarifa valle")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("customization"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🎨"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.personalization","Personalización")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descPersonalization","Idioma, tema, SoH, precios y seguridad")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),x.isAuthenticated&&e.jsxs("button",{onClick:()=>n(!0),className:"w-full flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/15 hover:bg-red-100 dark:hover:bg-red-900/25 rounded-2xl border border-red-100 dark:border-red-900/40 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🗑️"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-red-600 dark:text-red-400",children:t("settings.deleteAccount","Eliminar cuenta")}),e.jsx("p",{className:"text-xs text-red-500/80 dark:text-red-400/70",children:t("settings.deleteAccountDesc","Borra tu cuenta y todos tus datos de forma permanente")})]})]}),e.jsx("span",{className:"text-red-400 group-hover:translate-x-1 transition-transform",children:"→"})]})]}),e.jsx("button",{onClick:v,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:L},children:t("common.close","Cerrar")})]})})};export{Dt as default};
