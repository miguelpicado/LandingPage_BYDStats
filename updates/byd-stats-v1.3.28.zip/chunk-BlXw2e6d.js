import{d as r}from"./chunk-CxjUwVX2.js";const e=({children:o})=>r.createPortal(o,document.body);export{e as M};
