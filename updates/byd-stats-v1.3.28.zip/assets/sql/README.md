# Vendored sql.js (WASM)

These files are the **browser build** of [sql.js](https://github.com/sql-js/sql.js),
loaded at runtime via `<script>` injection in `src/hooks/useDatabase.ts`
(`window.initSqlJs`). The npm `sql.js` package is intentionally NOT imported —
its dist contains Node-only code (`fs`, `path`).

- `sql-wasm.min.js` — loader
- `sql-wasm.wasm` — SQLite WASM engine

**Pinned to the version in `package.json` (`sql.js@1.13.0`).**
To update after bumping the dependency, run `npm run sync:sqljs` and commit the result.
